(() => {
  if (window.__JP_KR_DUAL_SUB_LOADED__) return;
  window.__JP_KR_DUAL_SUB_LOADED__ = true;

  // Paste your DeepL API key (e.g. "xxxxx:fx") to prefer DeepL over Google.
  // Leave blank to use Google Translate's public endpoint.
  const DEEPL_API_KEY = '';
  const DEEPL_ENDPOINT = 'https://api-free.deepl.com/v2/translate';
  const TRANSLATE_ENDPOINT = 'https://translate.googleapis.com/translate_a/single';
  const TARGET_LANGS = ['ko', 'ja'];
  const translationCache = new Map();
  let lastCaption = '';
  let overlay = null;
  let settingsPanel = null;
  let settingsButton = null;
  let dragState = null;
  let lastRender = {
    sourceText: '',
    sourceLang: '',
    koText: '',
    jaText: ''
  };
  let lastDisplayedKey = '';
  const youtubeTrack = {
    videoId: '',
    cues: [],
    lang: 'en'
  };
  const externalTrack = {
    cues: [],
    label: 'FILE',
    lang: 'auto'
  };
  let lastTranscriptFetch = 0;

  const STORAGE_KEYS = {
    position: 'jpkr_overlay_position',
    visibility: 'jpkr_visibility'
  };

  const defaultVisibility = {
    source: true,
    ko: true,
    ja: true
  };

  const defaultStyle = {
    fontSize: 22,
    textColor: '#f6f6f6',
    background: '#000000d6',
    koColor: '#56a1ff',
    jaColor: '#ffb856',
    border: '#ffffff14'
  };

  const langLabel = {
    ja: 'JA',
    ko: 'KO',
    yt: 'YT',
    nf: 'NF',
    ext: 'FILE',
    dom: 'SRC'
  };

  function formatSourceLabel(sourceLang) {
    if (!sourceLang) return 'SRC';
    return langLabel[sourceLang] || sourceLang.toUpperCase();
  }

  function createOverlay() {
    if (overlay) return overlay;
    const container = document.createElement('div');
    container.id = 'jpkr-dual-container';
    container.innerHTML = `
      <div class="jpkr-line source" data-role="source"></div>
      <div class="jpkr-line ko" data-role="ko"></div>
      <div class="jpkr-line ja" data-role="ja"></div>
    `;
    document.body.appendChild(container);
    overlay = container;
    return overlay;
  }

  function collectCaptionText(selector) {
    if (!selector) return '';
    const nodes = document.querySelectorAll(selector);
    if (!nodes.length) return '';
    const seen = new Set();
    const parts = [];
    nodes.forEach((el) => {
      const t = (el.textContent || '').trim();
      if (!t || seen.has(t)) return;
      seen.add(t);
      parts.push(t);
    });
    return parts.join(' ').trim();
  }

  function isYouTube() {
    return /\.youtube\.com$/.test(location.hostname);
  }

  function isNetflix() {
    return /netflix\.com$/.test(location.hostname);
  }

  function getYouTubeVideoId() {
    const params = new URLSearchParams(location.search);
    const vParam = params.get('v');
    if (vParam) return vParam;
    const shorts = location.pathname.match(/\/shorts\/([^/?#]+)/);
    if (shorts) return shorts[1];
    const embed = location.pathname.match(/\/embed\/([^/?#]+)/);
    if (embed) return embed[1];
    return '';
  }

  function parseTimedTextEvents(events) {
    if (!Array.isArray(events)) return [];
    return events
      .map((ev) => {
        const text = Array.isArray(ev.segs) ? ev.segs.map((s) => s.utf8 || '').join('').trim() : '';
        const start = typeof ev.tStartMs === 'number' ? ev.tStartMs / 1000 : null;
        const dur = typeof ev.dDurationMs === 'number' ? ev.dDurationMs / 1000 : null;
        if (!text || start === null || dur === null) return null;
        return {
          start,
          end: start + dur,
          text
        };
      })
      .filter(Boolean);
  }

  async function fetchYouTubeTimedText(videoId) {
    const candidates = [
      { lang: 'en', kind: '' },
      { lang: 'en', kind: 'asr' },
      { lang: 'en-US', kind: '' },
      { lang: 'ja', kind: '' }
    ];

    for (const cand of candidates) {
      const params = new URLSearchParams({
        lang: cand.lang,
        v: videoId,
        fmt: 'json3'
      });
      if (cand.kind) params.set('kind', cand.kind);
      const url = `https://www.youtube.com/api/timedtext?${params.toString()}`;
      try {
        const res = await fetch(url, { credentials: 'include' });
        if (!res.ok) continue;
        const data = await res.json();
        const cues = parseTimedTextEvents(data?.events || []);
        if (cues.length) {
          return { cues, lang: cand.lang };
        }
      } catch (e) {
        // Continue trying other candidates
      }
    }

    return { cues: [], lang: '' };
  }

  async function maybeLoadYouTubeTranscript() {
    if (!isYouTube()) return;
    const videoId = getYouTubeVideoId();
    if (!videoId) return;
    if (youtubeTrack.videoId !== videoId) {
      youtubeTrack.videoId = videoId;
      youtubeTrack.cues = [];
    }
    const now = Date.now();
    if (youtubeTrack.videoId === videoId && youtubeTrack.cues.length) return;
    if (youtubeTrack.videoId === videoId && now - lastTranscriptFetch < 10000) return;
    lastTranscriptFetch = now;
    const { cues, lang } = await fetchYouTubeTimedText(videoId);
    youtubeTrack.videoId = videoId;
    youtubeTrack.cues = cues;
    youtubeTrack.lang = lang || 'en';
  }

  function getActiveCueText(cues, currentTime) {
    if (!Array.isArray(cues) || !cues.length) return '';
    if (typeof currentTime !== 'number' || Number.isNaN(currentTime)) return '';
    for (let i = cues.length - 1; i >= 0; i -= 1) {
      const cue = cues[i];
      if (currentTime >= cue.start && currentTime <= cue.end + 0.35) {
        return cue.text;
      }
    }
    return '';
  }

  function readYouTubeCaption() {
    const selectors = [
      '.ytp-caption-segment',
      '.ytp-caption-window-container .captions-text',
      '.ytp-caption-window-container span',
      '.ytp-caption-window-bottom span',
      '.captions-text span'
    ].join(',');
    return collectCaptionText(selectors);
  }

  function readNetflixCaption() {
    const selectors = [
      '.player-timedtext-text-container span',
      '.player-timedtext-text-container div',
      '[data-uia="player-timedtext"] span',
      '.player-timedtext span'
    ].join(',');
    return collectCaptionText(selectors);
  }

  function getCurrentCaption() {
    const video = document.querySelector('video');
    const time = video ? video.currentTime : null;

    const externalText = getActiveCueText(externalTrack.cues, time);
    if (externalText) {
      const normalized = normalizeCaption(externalText);
      if (!shouldSkipCaption(normalized)) return { text: normalized, source: 'ext' };
    }

    if (isYouTube()) {
      const ytText = getActiveCueText(youtubeTrack.cues, time);
      if (ytText) {
        const normalized = normalizeCaption(ytText);
        if (!shouldSkipCaption(normalized)) return { text: normalized, source: 'yt' };
      }
    }

    const domRaw = readYouTubeCaption() || readNetflixCaption() || '';
    const normalized = normalizeCaption(domRaw);
    if (shouldSkipCaption(normalized)) return { text: '', source: '' };
    const source = isNetflix() ? 'nf' : domRaw ? 'dom' : '';
    return { text: normalized, source };
  }

  function normalizeCaption(text) {
    if (!text) return '';
    const collapsed = text.replace(/\s+/g, ' ').trim();
    if (!collapsed) return '';
    // Remove obvious repeated runs (same phrase repeated back-to-back)
    const sentences = splitIntoChunks(collapsed);
    const unique = dedupeSentences(sentences);
    const joined = unique.join(' ');
    return collapseRepeatedBlocks(joined);
  }

  function autoEnableCaptions() {
    // YouTube
    const ytBtn =
      document.querySelector('.ytp-subtitles-button.ytp-button') ||
      document.querySelector('[aria-keyshortcuts="c"]');
    if (ytBtn && ytBtn.getAttribute('aria-pressed') !== 'true') {
      ytBtn.click();
    }

    // Netflix
    const nfBtn =
      document.querySelector('[data-uia="player-subs-button"]') ||
      document.querySelector('.button-nfplayerSubtitles');
    if (nfBtn && nfBtn.getAttribute('aria-pressed') !== 'true') {
      nfBtn.click();
    }
  }

  function loadPosition() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.position);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function savePosition(pos) {
    try {
      localStorage.setItem(STORAGE_KEYS.position, JSON.stringify(pos));
    } catch (e) {
      console.warn('Failed to save position', e);
    }
  }

  function loadVisibility() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.visibility);
      return raw ? { ...defaultVisibility, ...JSON.parse(raw) } : { ...defaultVisibility };
    } catch (e) {
      return { ...defaultVisibility };
    }
  }

  function saveVisibility(vis) {
    try {
      localStorage.setItem(STORAGE_KEYS.visibility, JSON.stringify(vis));
    } catch (e) {
      console.warn('Failed to save visibility', e);
    }
  }

  function loadStyleSettings() {
    try {
      const raw = localStorage.getItem('jpkr_style');
      return raw ? { ...defaultStyle, ...JSON.parse(raw) } : { ...defaultStyle };
    } catch (e) {
      return { ...defaultStyle };
    }
  }

  function saveStyleSettings(style) {
    try {
      localStorage.setItem('jpkr_style', JSON.stringify(style));
    } catch (e) {
      console.warn('Failed to save style', e);
    }
  }

  async function translateWithGoogle(text, target) {
    const url = `${TRANSLATE_ENDPOINT}?client=gtx&dt=t&sl=auto&tl=${target}&q=${encodeURIComponent(
      text
    )}`;

    try {
      const res = await fetch(url);
      const data = await res.json();
      const translated = Array.isArray(data?.[0])
        ? data[0]
            .map((chunk) => (Array.isArray(chunk) ? chunk[0] : ''))
            .join(' ')
            .trim()
        : '';
      const detectedSource = data?.[2] || 'auto';
      return { translated, detectedSource };
    } catch (error) {
      console.warn('Translation failed', error);
      return { translated: '', detectedSource: 'auto' };
    }
  }

  async function translateWithDeepL(text, target) {
    const body = new URLSearchParams({
      auth_key: DEEPL_API_KEY.trim(),
      text,
      target_lang: target.toUpperCase()
    });

    try {
      const res = await fetch(DEEPL_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
      });
      const data = await res.json();
      const translation = data?.translations?.[0];
      const translated = translation?.text?.trim() || '';
      const detectedSource = translation?.detected_source_language?.toLowerCase() || 'auto';
      return { translated, detectedSource };
    } catch (error) {
      console.warn('DeepL translation failed', error);
      return { translated: '', detectedSource: 'auto' };
    }
  }

  async function translateChunks(text, target) {
    const sentences = splitIntoChunks(text);
    const results = [];
    for (const sentence of sentences) {
      const translated = await translateText(sentence, target);
      results.push(translated);
    }
    const joined = results
      .map((r) => r.translated)
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim();
    const detectedSource = results.find((r) => r.detectedSource)?.detectedSource || 'auto';
    return { translated: joined, detectedSource };
  }

  async function translateText(text, target) {
    const provider = DEEPL_API_KEY.trim() ? 'deepl' : 'google';
    const cacheKey = `${provider}:${target}:${text}`;
    if (translationCache.has(cacheKey)) {
      return translationCache.get(cacheKey);
    }

    const primary =
      provider === 'deepl'
        ? await translateWithDeepL(text, target)
        : await translateWithGoogle(text, target);
    if (primary.translated) {
      translationCache.set(cacheKey, primary);
      return primary;
    }

    if (provider === 'deepl') {
      const fallback = await translateWithGoogle(text, target);
      translationCache.set(`google:${target}:${text}`, fallback);
      return fallback;
    }

    return primary;
  }

  function splitIntoChunks(text) {
    const chunks = text
      .split(/(?<=[。．\.！？!?])/)
      .map((t) => t.trim())
      .filter(Boolean);
    if (chunks.length === 0) return [text];
    // Merge tiny chunks to avoid over-splitting
    const merged = [];
    let buffer = '';
    for (const c of chunks) {
      const combined = buffer ? `${buffer} ${c}` : c;
      if (combined.length < 25) {
        buffer = combined;
      } else {
        if (buffer) merged.push(buffer);
        buffer = c;
      }
    }
    if (buffer) merged.push(buffer);
    return dedupeSentences(merged);
  }

  function dedupeSentences(list) {
    const seen = new Set();
    const out = [];
    for (const item of list) {
      const key = item.trim();
      if (!key || seen.has(key)) continue;
      seen.add(key);
      out.push(key);
    }
    return out;
  }

  function collapseRepeatedBlocks(text) {
    if (!text) return '';
    // Collapse identical lines first
    const lineParts = Array.from(
      new Set(
        text
          .split(/\n+/)
          .map((l) => l.trim())
          .filter(Boolean)
      )
    );
    const lineJoined = lineParts.join(' ');
    const tokens = lineJoined.split(' ').filter(Boolean);
    if (tokens.length < 4) return lineJoined;
    const maxBase = Math.min(tokens.length / 2, 60);
    for (let base = 1; base <= maxBase; base += 1) {
      let matchLen = 0;
      for (let i = 0; i < tokens.length; i += 1) {
        if (tokens[i] === tokens[i % base]) {
          matchLen += 1;
        } else {
          matchLen = 0;
          break;
        }
      }
      const repeatCount = Math.floor(tokens.length / base);
      if (matchLen === tokens.length && repeatCount >= 2) {
        return tokens.slice(0, base).join(' ');
      }
    }
    // Deduplicate by sentence/chunk again to remove alternating repeats
    const sentenceParts = lineJoined
      .split(/(?<=[。．\.！？!?])/)
      .map((t) => t.trim())
      .filter(Boolean);
    const uniqueSentence = dedupeSentences(sentenceParts);
    return uniqueSentence.join(' ');
  }

  function squeezeRepeats(text) {
    if (!text) return '';
    const tokens = text.split(' ');
    const reduced = [];
    let run = 0;
    let prev = '';
    for (const t of tokens) {
      if (t === prev) {
        run += 1;
        if (run < 2) reduced.push(t);
      } else {
        run = 0;
        reduced.push(t);
      }
      prev = t;
    }
    return reduced.join(' ');
  }

  function shouldSkipCaption(text) {
    if (!text) return true;
    if (text.length < 2) return true;
    const lower = text.toLowerCase();
    // Common non-speech cues
    const nonSpeechPatterns = [
      /^\[.*(music|musique|음악|音楽|bgm|♪|♫|applause|clap|拍手).*\]$/i,
      /^\(.*(music|음악|音楽|bgm|♪|♫|applause|clap|拍手).*\)$/i,
      /^♪+$/i,
      /^♬+$/i
    ];
    if (nonSpeechPatterns.some((re) => re.test(text))) return true;
    // Heuristic: extremely repetitive short words (e.g., "ha ha ha")
    const uniqueTokens = new Set(text.split(' '));
    if (uniqueTokens.size === 1 && text.split(' ').length > 3) return true;
    // Ignore if mostly symbols
    const letters = text.replace(/[^A-Za-z\u3040-\u30ff\u4e00-\u9faf\uac00-\ud7af0-9]/g, '');
    return letters.length < 2;
  }

  function parseTimestamp(str) {
    const match = str.match(/(\d{1,2}):(\d{2}):(\d{2})[.,](\d{1,3})/);
    if (!match) return null;
    const [_, h, m, s, ms] = match;
    return Number(h) * 3600 + Number(m) * 60 + Number(s) + Number(ms) / 1000;
  }

  function parseCueBlock(lines) {
    if (!lines.length) return null;
    let timeLine = lines[0];
    let textLines = lines.slice(1);
    if (/^\d+$/.test(lines[0]) && lines[1]) {
      timeLine = lines[1];
      textLines = lines.slice(2);
    }
    const [startStr, endStr] = timeLine.split('-->').map((t) => t.trim());
    const start = parseTimestamp(startStr);
    const end = parseTimestamp(endStr || '');
    if (start === null || end === null) return null;
    const text = textLines.join(' ').trim();
    if (!text) return null;
    return { start, end, text };
  }

  function parseSrt(content) {
    const blocks = content
      .replace(/\r\n/g, '\n')
      .split(/\n{2,}/)
      .map((b) => b.trim())
      .filter(Boolean);
    const cues = [];
    for (const block of blocks) {
      const lines = block.split('\n');
      const cue = parseCueBlock(lines);
      if (cue) cues.push(cue);
    }
    return cues;
  }

  function parseVtt(content) {
    const cleaned = content.replace(/^WEBVTT[^\n]*\n/i, '').trim();
    return parseSrt(cleaned);
  }

  function parseSubtitleFile(text) {
    if (!text) return [];
    const trimmed = text.trim();
    if (!trimmed) return [];
    if (trimmed.startsWith('WEBVTT')) return parseVtt(trimmed);
    return parseSrt(trimmed);
  }

  function setExternalTrackFromText(text, label) {
    const cues = parseSubtitleFile(text);
    externalTrack.cues = cues;
    externalTrack.label = label || 'FILE';
    externalTrack.lang = 'auto';
    if (!cues.length) {
      console.warn('No cues parsed from external file');
    }
  }

  function setLineContent(el, label, lines, visible) {
    el.dataset.label = label;
    el.textContent = lines.length ? lines.slice(0, 2).join('\n') : '';
    el.style.display = lines.length && visible ? 'block' : 'none';
  }

  function uniqueLines(lines) {
    const seen = new Set();
    return lines.filter((line) => {
      const key = (line || '').trim();
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function updateOverlay({ sourceText, sourceLang, koText, jaText }) {
    const root = createOverlay();
    const sourceLine = root.querySelector('[data-role="source"]');
    const koLine = root.querySelector('[data-role="ko"]');
    const jaLine = root.querySelector('[data-role="ja"]');

    const sourceLines = uniqueLines(splitIntoChunks(sourceText).map(squeezeRepeats).filter(Boolean));
    const koLines = uniqueLines(splitIntoChunks(koText).map(squeezeRepeats).filter(Boolean));
    const jaLines = uniqueLines(splitIntoChunks(jaText).map(squeezeRepeats).filter(Boolean));

    const showSource = Boolean(sourceLines.length);
    const showKo = Boolean(koLines.length);
    const showJa = Boolean(jaLines.length);

    setLineContent(sourceLine, formatSourceLabel(sourceLang), sourceLines, visibility.source && showSource);
    setLineContent(koLine, langLabel.ko, koLines, visibility.ko && showKo);
    setLineContent(jaLine, langLabel.ja, jaLines, visibility.ja && showJa);

    const hasContent = showSource || showKo || showJa;
    const newKey = `${sourceLine.dataset.label}:${sourceLine.textContent}||${koLine.dataset.label}:${koLine.textContent}||${jaLine.dataset.label}:${jaLine.textContent}`;
    if (newKey === lastDisplayedKey) return;
    lastDisplayedKey = newKey;
    root.style.display = hasContent ? 'flex' : 'none';
    lastRender = { sourceText, sourceLang, koText, jaText };
  }

  async function handleCaption(text, sourceLabel) {
    const cleanedSource = collapseRepeatedBlocks(text);
    const [ko, ja] = await Promise.all(TARGET_LANGS.map((lang) => translateChunks(cleanedSource, lang)));
    const sourceLang = sourceLabel || ko?.detectedSource || ja?.detectedSource || 'auto';
    const koText = collapseRepeatedBlocks(ko?.translated || '');
    const jaText = collapseRepeatedBlocks(ja?.translated || '');

    updateOverlay({
      sourceText: cleanedSource,
      sourceLang,
      koText,
      jaText
    });
  }

  const visibility = loadVisibility();
  let currentStyle = loadStyleSettings();

  function applyPosition() {
    const pos = loadPosition();
    const root = createOverlay();
    if (pos && typeof pos.left === 'number' && typeof pos.top === 'number') {
      root.style.left = `${pos.left}px`;
      root.style.top = `${pos.top}px`;
      root.style.bottom = 'auto';
      root.style.transform = 'translate(0, 0)';
    } else {
      root.style.left = '50%';
      root.style.top = 'auto';
      root.style.bottom = '12%';
      root.style.transform = 'translateX(-50%)';
    }
  }

  function startDrag(e) {
    const root = createOverlay();
    dragState = {
      startX: e.clientX,
      startY: e.clientY,
      origLeft: root.offsetLeft,
      origTop: root.offsetTop
    };
    root.classList.add('dragging');
    document.addEventListener('mousemove', onDrag);
    document.addEventListener('mouseup', endDrag);
  }

  function onDrag(e) {
    if (!dragState) return;
    const root = createOverlay();
    const dx = e.clientX - dragState.startX;
    const dy = e.clientY - dragState.startY;
    const newLeft = dragState.origLeft + dx;
    const newTop = dragState.origTop + dy;
    root.style.left = `${newLeft}px`;
    root.style.top = `${newTop}px`;
    root.style.bottom = 'auto';
    root.style.transform = 'translate(0, 0)';
  }

  function endDrag() {
    const root = createOverlay();
    root.classList.remove('dragging');
    const pos = { left: root.offsetLeft, top: root.offsetTop };
    savePosition(pos);
    document.removeEventListener('mousemove', onDrag);
    document.removeEventListener('mouseup', endDrag);
    dragState = null;
  }

  function attachDrag() {
    const root = createOverlay();
    root.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      startDrag(e);
    });
  }

  function toggleSidebar() {
    const panel = createSettingsPanel();
    panel.classList.toggle('open');
  }

  function createSettingsPanel() {
    if (settingsPanel) return settingsPanel;
    const panel = document.createElement('div');
    panel.id = 'jpkr-settings-panel';
    const styleSettings = loadStyleSettings();
    currentStyle = { ...styleSettings };
    panel.innerHTML = `
      <div class="jpkr-settings-header">
        <div class="jpkr-title">Subtitles Control</div>
        <div class="jpkr-subtitle">Dual JP · KR</div>
      </div>
      <div class="jpkr-section">
        <div class="jpkr-label">Visibility</div>
        <label class="jpkr-toggle"><input type="checkbox" data-role="show-source" ${visibility.source ? 'checked' : ''}>Show original</label>
        <label class="jpkr-toggle"><input type="checkbox" data-role="show-ko" ${visibility.ko ? 'checked' : ''}>Show Korean</label>
        <label class="jpkr-toggle"><input type="checkbox" data-role="show-ja" ${visibility.ja ? 'checked' : ''}>Show Japanese</label>
      </div>
      <div class="jpkr-section">
        <div class="jpkr-label">Style</div>
        <div class="jpkr-control">
          <label>Font size</label>
          <div class="jpkr-range">
            <input type="range" min="14" max="36" value="${styleSettings.fontSize}" data-role="font-size">
            <span data-role="font-size-value">${styleSettings.fontSize}px</span>
          </div>
        </div>
        <div class="jpkr-control">
          <label>Text color</label>
          <input type="color" value="${styleSettings.textColor}" data-role="text-color">
        </div>
        <div class="jpkr-control">
          <label>Background</label>
          <input type="color" value="${styleSettings.background.slice(0, 7)}" data-role="bg-color">
        </div>
        <div class="jpkr-control">
          <label>KO accent</label>
          <input type="color" value="${styleSettings.koColor}" data-role="ko-color">
        </div>
        <div class="jpkr-control">
          <label>JA accent</label>
          <input type="color" value="${styleSettings.jaColor}" data-role="ja-color">
        </div>
      </div>
      <div class="jpkr-section">
        <div class="jpkr-label">Subtitle source</div>
        <div class="jpkr-control">
          <label for="jpkr-subfile">Load .srt / .vtt</label>
          <input type="file" id="jpkr-subfile" data-role="subtitle-file" accept=".srt,.vtt,text/vtt,text/plain">
        </div>
        <div class="jpkr-control">
          <button data-role="clear-subfile">Clear loaded file</button>
        </div>
      </div>
      <div class="jpkr-actions">
        <button data-role="reset-pos">Reset position</button>
        <button data-role="reset-style">Reset style</button>
      </div>
    `;
    document.body.appendChild(panel);
    panel.querySelector('[data-role="show-source"]').addEventListener('change', (e) => {
      visibility.source = e.target.checked;
      saveVisibility(visibility);
      updateOverlay(lastRender);
    });
    panel.querySelector('[data-role="show-ko"]').addEventListener('change', (e) => {
      visibility.ko = e.target.checked;
      saveVisibility(visibility);
      updateOverlay(lastRender);
    });
    panel.querySelector('[data-role="show-ja"]').addEventListener('change', (e) => {
      visibility.ja = e.target.checked;
      saveVisibility(visibility);
      updateOverlay(lastRender);
    });
    panel.querySelector('[data-role="reset-pos"]').addEventListener('click', () => {
      localStorage.removeItem(STORAGE_KEYS.position);
      applyPosition();
    });
    panel.querySelector('[data-role="reset-style"]').addEventListener('click', () => {
      currentStyle = { ...defaultStyle };
      saveStyleSettings(currentStyle);
      applyStyle(currentStyle);
      refreshStyleControls(panel, currentStyle);
      updateOverlay(lastRender);
    });
    panel.querySelector('[data-role="font-size"]').addEventListener('input', (e) => {
      currentStyle = { ...loadStyleSettings(), fontSize: Number(e.target.value) };
      saveStyleSettings(currentStyle);
      applyStyle(currentStyle);
      panel.querySelector('[data-role="font-size-value"]').textContent = `${currentStyle.fontSize}px`;
      updateOverlay(lastRender);
    });
    panel.querySelector('[data-role="text-color"]').addEventListener('input', (e) => {
      currentStyle = { ...loadStyleSettings(), textColor: e.target.value };
      saveStyleSettings(currentStyle);
      applyStyle(currentStyle);
      updateOverlay(lastRender);
    });
    panel.querySelector('[data-role="bg-color"]').addEventListener('input', (e) => {
      currentStyle = { ...loadStyleSettings(), background: e.target.value + 'cc' };
      saveStyleSettings(currentStyle);
      applyStyle(currentStyle);
      updateOverlay(lastRender);
    });
    panel.querySelector('[data-role="ko-color"]').addEventListener('input', (e) => {
      currentStyle = { ...loadStyleSettings(), koColor: e.target.value };
      saveStyleSettings(currentStyle);
      applyStyle(currentStyle);
      updateOverlay(lastRender);
    });
    panel.querySelector('[data-role="ja-color"]').addEventListener('input', (e) => {
      currentStyle = { ...loadStyleSettings(), jaColor: e.target.value };
      saveStyleSettings(currentStyle);
      applyStyle(currentStyle);
      updateOverlay(lastRender);
    });
    panel.querySelector('[data-role="subtitle-file"]').addEventListener('change', (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        const text = evt.target?.result ? String(evt.target.result) : '';
        setExternalTrackFromText(text, file.name || 'FILE');
        lastCaption = '';
      };
      reader.readAsText(file);
    });
    panel.querySelector('[data-role="clear-subfile"]').addEventListener('click', () => {
      externalTrack.cues = [];
      externalTrack.label = 'FILE';
      externalTrack.lang = 'auto';
      lastCaption = '';
    });
    settingsPanel = panel;
    return panel;
  }

  function refreshStyleControls(panel, styleSettings) {
    panel.querySelector('[data-role="font-size"]').value = styleSettings.fontSize;
    panel.querySelector('[data-role="font-size-value"]').textContent = `${styleSettings.fontSize}px`;
    panel.querySelector('[data-role="text-color"]').value = styleSettings.textColor;
    panel.querySelector('[data-role="bg-color"]').value = styleSettings.background.slice(0, 7);
    panel.querySelector('[data-role="ko-color"]').value = styleSettings.koColor;
    panel.querySelector('[data-role="ja-color"]').value = styleSettings.jaColor;
  }

  function applyStyle(styleSettings) {
    const root = createOverlay();
    root.style.setProperty('--jpkr-font-size', `${styleSettings.fontSize}px`);
    root.style.setProperty('--jpkr-text-color', styleSettings.textColor);
    root.style.setProperty('--jpkr-bg-color', styleSettings.background);
    root.style.setProperty('--jpkr-ko-color', styleSettings.koColor);
    root.style.setProperty('--jpkr-ja-color', styleSettings.jaColor);
    root.style.setProperty('--jpkr-border-color', styleSettings.border);
  }

  function createSettingsButton() {
    if (settingsButton) return settingsButton;
    const btn = document.createElement('button');
    btn.id = 'jpkr-settings-toggle';
    btn.textContent = 'Subs';
    btn.addEventListener('click', toggleSidebar);
    document.body.appendChild(btn);
    settingsButton = btn;
    return btn;
  }

  function startCaptionWatcher() {
    createOverlay();
    createSettingsButton();
    createSettingsPanel();
    applyStyle(currentStyle);
    applyPosition();
    attachDrag();
    setInterval(() => {
      autoEnableCaptions();
      if (isYouTube()) {
        maybeLoadYouTubeTranscript();
      }

      const { text: caption = '', source: sourceLabel = '' } = getCurrentCaption() || {
        text: '',
        source: ''
      };
      if (!caption) {
        if (lastRender.sourceText) {
          updateOverlay(lastRender);
        } else {
          lastCaption = '';
          updateOverlay({ sourceText: '', sourceLang: '', koText: '', jaText: '' });
        }
        return;
      }

      const captionKey = `${sourceLabel}:${caption}`;
      if (captionKey === lastCaption) return;
      lastCaption = captionKey;
      handleCaption(caption, sourceLabel);
    }, 500);
  }

  startCaptionWatcher();
})(); 
